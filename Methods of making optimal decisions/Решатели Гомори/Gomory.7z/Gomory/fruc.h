#ifndef __FRUC_H
#define __FRUC_H
#include <sysutils.hpp>
class TFruc
{
 public:
  __int64 x,y;

  TFruc()
  {
   x=0;
   y=1;
  }

  TFruc operator +(TFruc b)
  {
    TFruc d;
    d.y=y*b.y;
    d.x=x*b.y+y*b.x;
    d.reduce();
    return d;
  }

  TFruc operator -(TFruc b)
  {
    TFruc d;
    d.y=y*b.y;
    d.x=x*b.y-y*b.x;
    d.reduce();
    return d;
  }

  TFruc operator -()
  {
    TFruc d;
    d.x=-x;
    d.y=y;
    return d;
  }

  TFruc operator *(TFruc b)
  {
    TFruc d;
    d.y=y*b.y;
    d.x=x*b.x;
    d.reduce();
    return d;
  }

  TFruc operator *(__int64 b)
  {
    TFruc d;
    d.x=x*b;
    d.y=y;
    d.reduce();
    return d;
  }

  TFruc operator /(TFruc b)
  {
    TFruc d;
    d.y=y*b.x;
    d.x=x*b.y;
    if(d.y<0)
    {
      d.y=-d.y;
      d.x=-d.x;
    };
    d.reduce();
    return d;
  }

  TFruc operator +(__int64 b)
  {
    TFruc d;
    d.x=x+y*b;
    d.y=y;
    d.reduce();
    return d;
  }

  TFruc operator -(__int64 b)
  {
    TFruc d;
    d.x=x-y*b;
    d.y=y;
    d.reduce();
    return d;
  }

  TFruc& operator =( TFruc a )
  {
    x=a.x;
    y=a.y;
    return *this;
  }

  TFruc& operator =(__int64 a)
  {
    x=a;
    y=1;
    return *this;
  }

  __int64 operator <=(TFruc a)
  {
    __int64 x1,x2;
    x1=x*a.y;
    x2=a.x*y;
    return(x1<=x2);
  }

  __int64 operator <(TFruc a)
  {
    __int64 x1,x2;
    x1=x*a.y;
    x2=a.x*y;
    return(x1<x2);
  }

  __int64 operator >(TFruc a)
  {
    __int64 x1,x2;
    x1=x*a.y;
    x2=a.x*y;
    return(x1>x2);
  }

  __int64 operator >=(TFruc a)
  {
    __int64 x1,x2;
    x1=x*a.y;
    x2=a.x*y;
    return(x1>=x2);
  }

  __int64 operator ==(TFruc a)
  {
    __int64 x1,x2;
    x1=x*a.y;
    x2=a.x*y;
    return(x1==x2);
  }

  __int64 sign()
  {
   return(x*y);
  }

  TFruc operator !()
  {
    __int64 pro;
    TFruc d;
    if(x>=0)
    {
      d.x=x%y;
      d.y=y;
    }else
    {
      d.x=y+x%y;
      d.y=y;
    }
    return d;
  }

  TFruc& operator ~()
  {
    reduce();
    return *this;
  }

  void reduce()
  {
    __int64 a,b;

    a=abs(x);
    b=abs(y);
    if( a < 0 || b < 0 )throw Exception("������������! ������������ ��������� ������������");
    if( b==0 )throw Exception("����������� ����� ����");

    while((a!=b)&&(a!=0))
    {
     while(a>b)a-=b;
     while(b>a)b-=a;
    }
    x/=b;
    y/=b;
  }

 };
#endif

