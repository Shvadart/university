//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "PrgForm.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TProgressForm *ProgressForm;
//---------------------------------------------------------------------------
__fastcall TProgressForm::TProgressForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TProgressForm::BitBtn1Click(TObject *Sender)
{
 MainForm->solve->Suspend();
 MainForm->SolveEnd(NULL);
 delete MainForm->solve;
}
//---------------------------------------------------------------------------
void __fastcall TProgressForm::FormClose(TObject *Sender,
      TCloseAction &Action)
{
 Action = caFree;        
}
//---------------------------------------------------------------------------
