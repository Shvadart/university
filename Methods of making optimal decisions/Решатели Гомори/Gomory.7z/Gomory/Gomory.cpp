//---------------------------------------------------------------------------
#include <vcl.h>
#include <windows.h>
#pragma hdrstop
USERES("Gomory.res");
USEFORM("Main.cpp", MainForm);
USEUNIT("misc.pas");
USEUNIT("gsolv_c.cpp");
USEFORM("PrgForm.cpp", ProgressForm);
//---------------------------------------------------------------------------
#include "main.h"
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE Inst, HINSTANCE, LPSTR param, int)
{
        try
        {
                 char buf[80];
                 GetModuleFileName( Inst, buf, 80 );
                 WorkDir = ExtractFilePath( AnsiString(buf) );
                 Application->Initialize();
                 Application->CreateForm(__classid(TMainForm), &MainForm);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
