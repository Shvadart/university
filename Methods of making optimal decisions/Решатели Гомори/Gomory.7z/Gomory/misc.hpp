// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'misc.pas' rev: 5.00

#ifndef miscHPP
#define miscHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Misc
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall WriteText(Graphics::TCanvas* ACanvas, const Windows::TRect &ARect, int 
	DX, int DY, const AnsiString Text, Classes::TAlignment Alignment);

}	/* namespace Misc */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Misc;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// misc
