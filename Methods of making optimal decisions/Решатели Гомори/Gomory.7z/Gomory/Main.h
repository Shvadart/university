//---------------------------------------------------------------------------
#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <checklst.hpp>
#include <Grids.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <CheckLst.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
        TPageControl *PageControl;
        TTabSheet *tsSourceData;
        TTabSheet *tsResults;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TDrawGrid *dwgInput1;
        TDrawGrid *dwgInput2;
        TEdit *edVar;
        TEdit *edLim;
        TCheckBox *cbEachStep;
        TCheckListBox *clbIntVar;
        TComboBox *cbAlg;
        TBitBtn *bbSolve;
        TBitBtn *bbExit;
        TMemo *mRes;
        TBitBtn *BitBtn4;
        TBitBtn *BitBtn5;
        TBitBtn *BitBtn6;
        TOpenDialog *OpenDialog;
        TTabSheet *tsHelp;
        TPanel *Panel1;
        TMemo *Memo1;
        TSaveDialog *SaveDialog;
        TTabSheet *TabSheet1;
        TImage *Image1;
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall dwgInput2DrawCell(TObject *Sender, int Col,
          int Row, TRect &Rect, TGridDrawState State);
        void __fastcall dwgInput2GetEditText(TObject *Sender, int ACol,
          int ARow, AnsiString &Value);
        void __fastcall dwgInput2SelectCell(TObject *Sender, int Col,
          int Row, bool &CanSelect);
        void __fastcall dwgInput2SetEditText(TObject *Sender, int ACol,
          int ARow, const AnsiString Value);
        void __fastcall dwgInput2MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall dwgInput2MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall dwgInput2MouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall dwgInput1DrawCell(TObject *Sender, int Col,
          int Row, TRect &Rect, TGridDrawState State);
        void __fastcall dwgInput1GetEditText(TObject *Sender, int ACol,
          int ARow, AnsiString &Value);
        void __fastcall dwgInput1SelectCell(TObject *Sender, int Col,
          int Row, bool &CanSelect);
        void __fastcall dwgInput1SetEditText(TObject *Sender, int ACol,
          int ARow, const AnsiString Value);
        void __fastcall dwgInput1MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall dwgInput1MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall dwgInput1MouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);


        void __fastcall seExit(TObject *Sender);
        void __fastcall seKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);


        void __fastcall cbAlgChange(TObject *Sender);
        void __fastcall BitBtn5Click(TObject *Sender);
        void __fastcall BitBtn4Click(TObject *Sender);
        void __fastcall BitBtn6Click(TObject *Sender);
      //  void __fastcall bbInfoClick(TObject *Sender);
        
        void __fastcall clbIntVarEnter(TObject *Sender);
private:	// User declarations
    int n,m;
    int *Q;
    int *K;
    Boolean Draging;
    //Boolean Draging;
    Boolean PressedK;
    Boolean PressedQ;
    int PressedRow;
    void AllocArrays();
    void UpdateIntVarList();
public:		// User declarations
    
    TThread *solve;
    __fastcall TMainForm(TComponent* Owner);
    void __fastcall SolveEnd(TObject *Sender);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
extern AnsiString WorkDir;
//---------------------------------------------------------------------------
#endif
